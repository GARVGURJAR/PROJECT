//gallery
document.getElementById("gallery-button").addEventListener("click", function() {
    document.getElementById("gallery").scrollIntoView({ behavior: "smooth" });
});





//services
document.getElementById("services-button").addEventListener("click", function() {
    document.getElementById("services").scrollIntoView({ behavior: "smooth" });
});
//team
document.getElementById("team-button").addEventListener("click", function() {
    document.getElementById("team").scrollIntoView({ behavior: "smooth" });
});



//feedback
document.getElementById("feedback-button").addEventListener("click", function() {
    document.getElementById("feedback").scrollIntoView({ behavior: "smooth" });
});